import { LaunchScreen } from 'meteor/launch-screen';

export const listRenderHold = LaunchScreen.hold();
